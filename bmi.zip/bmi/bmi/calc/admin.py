from django.contrib import admin
from .models import Measurements
admin.site.register(Measurements)