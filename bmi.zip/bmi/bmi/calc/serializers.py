from rest_framework import serializers
from .models import Measurements


class MeasurementsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Measurements
        fields = ['height', 'weight', 'bmi']

