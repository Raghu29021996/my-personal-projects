from django.db import models

class Measurements(models.Model):
    height = models.FloatField()
    weight = models.FloatField()
    bmi = models.IntegerField()


    def bmi(self):
        return self.weight / self.height ** 2
