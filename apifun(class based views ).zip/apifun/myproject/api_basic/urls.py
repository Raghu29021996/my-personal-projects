from django.urls import path
from .views import InfoDetails,InfoAPIView

urlpatterns = [

    path('info/', InfoAPIView.as_view()),
    path('detail/<int:id>/', InfoDetails.as_view()),
]