
from rest_framework import serializers
from .models import Info


class InfoSerializer(serializers.Serializer):

    username = serializers.CharField(max_length=100)
    name = serializers.CharField(max_length=100)
    lastname = serializers.EmailField(max_length=100)
    date = serializers.DateTimeField()

    class infoSerializer(serializers.ModelSerializer):
        class Meta:
            model = Info
            fields = ['username', 'name', 'lastname']

    def create(self, validated_data):
        # Create and return a new `Article` instance, given the validated data.
        return Info.objects.create(validated_data)

    def update(self, instance, validated_data):
        # Update and return an existing `Article` instance, given the validated data.

        instance.username = validated_data.get('title', instance.username)
        instance.name = validated_data.get('author', instance.name)
        instance.lastname = validated_data.get('email', instance.lastname)
        instance.date = validated_data.get('date', instance.date)
        instance.save()
        return instance